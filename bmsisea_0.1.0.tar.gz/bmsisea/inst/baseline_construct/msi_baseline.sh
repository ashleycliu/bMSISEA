usage() { echo "Usage: $0 [-d <string>] [-p <string>]" 1>&2; exit 1; }

while getopts ":d:p:" o; do
    case "${o}" in
        s)
            s=${OPTARG}
            ((s == 45 || s == 90)) || usage
            ;;
        d)
            script_dir=${OPTARG}
            ;;
        *)
            usage
            ;;
    esac
done
shift $((OPTIND-1))

if [ -z "${s}" ] || [ -z "${p}" ]; then
    usage
fi

echo "s = ${s}"
echo "p = ${p}"

# 1) Catalog all homo-polymers in your host genome.
${script_dir}/inst/extdata/msisensor scan -d ${reference_fasta} -o ${outdir}/genome_microsatellites.list -l 15 
# 2) Limit the list of microsatellites to those presented in your capture design.
custom_assay_bed_name=`basename ${custom_assay_bed}`
custom_assay_bed_name="${custom_assay_bed_name%.*}"
bedtools intersect -a -o ${outdir}/genome_microsatellites.list -b ${custom_assay_bed} -f 1 -wa > ${outdir}/${custom_assay_bed_name}.microsatellites.bed
cut -f 4 ${outdir}/${custom_assay_bed_name}.microsatellites.bed| awk 'BEGIN{FS="-";OFS="\t"}{print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10}' > ${outdir}/${custom_assay_bed_name}.msi.list.tmp
head -1  ${outdir}/genome_microsatellites.list | cat - ${outdir}/${custom_assay_bed_name}.msi.list.tmp > ${outdir}/${custom_assay_bed_name}.msi.list
rm ${outdir}/${custom_assay_bed_name}.msi.list.tmp -f  
# 3)  Select microsatellite marker loci and construct baseline files
${rscript} ${script_dir}/constructBaseline-pre.R --panelName ${custom_assay_bed_name}  -p Novaseq --normalDir ${mssDir} --tumorDir ${msiDir}
# 4) Run baseline of new markers for negative plasma cases to include mean and sd of H values to baseline
${rscript} ${script_dir}/constructBaseline-post.R --panelName ${custom_assay_bed_name}  -p Novaseq --negDir ${plaDir} 

