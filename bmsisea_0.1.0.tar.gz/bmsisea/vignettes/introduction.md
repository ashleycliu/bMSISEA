---
title: "bMSISEA: detecting of microsatellite instability from circulating tumor DNA by deep targeted sequencing"
author: "Chenglin Liu"
date: "2018-12-11"
output: rmarkdown::pdf_document
vignette: >
  %\VignetteIndexEntry{bmsisea}
  %\VignetteEngine{knitr::rmarkdown}
  %\VignetteEncoding{UTF-8}
---
The R package bMSISEA detect the status of MSI from ctDNA samples. Studies show a high sensitivity of 93.4% with suffiecient ctDNA content (tumor allele
frequency (maxAF) > 0.2%) and larger than 99% specificity. \\
Copyright belongs to Burning Rock Dx., China. This project is free for use by Academic users
but not for commercial uses. Please see enclosed license agreement for details and conditions of use.

## bMSISEA: detecting of microsatellite instability from circulating tumor DNA by deep targeted sequencing
### Required Input files:
- bamFile : plasma sample of interest aligned against reference genome, provided in bam format.
- msi_markers : MSI marker site file (see example under "inst/example/markerLoci.msi") - specifies the selected marker loci. User generates this file with baselineConstruction function.
- msi_baseline : MSI baseline file (see example under "inst/example/baseline.rdata") - describes statistics of each marker locus, as well as mean and standard deviation of H value of each locus, as calculated from an MSI negative population (white blood cell samples or MSI negative plasma). User generates this file with baselineConstruction function (see below). NOTE: Baseline statistics vary markedly from assay-to-assay and lab-to-lab. It is CRITICAL that you prepare a baseline file that is specific for your analytic process, and for which data have been generated using the same protocols. Sensitivies is limited using low coverage data. Previous studies has shown a minimum of 5000X is required for targeted sequencing.
### Other required parameters
- coverageFilePath: the file of coverage data, the ouput file of function coverageCaller and input file for function siteCoverageData
- msi_threshold : the cutoff of MS_score to determine MSI-H/MSS.
- sample name: the name of the plasma sample

### Output
a list of three element:
 -     msi_status      character, MSI-H / MSS
 -      MS_score        numeric, the ms score      
 -      lociInfo        data frame, the statistics of each loci

## Detection Code
The MSI detection is fulfilled by three steps.


```r
library(bmsisea)
msi_markers <- system.file("example", "markerLoci.msi", package = "bmsisea")
msi_baseline <- get(load(system.file("example", "baseline.rdata", package = "bmsisea")))
coverageFilePath <- system.file("example", "test_msi_dis", package = "bmsisea")
msi_threshold <- 15
## Not run: the bamFile is not available
## coverageCaller(bamFile, msi_markers, sub("_dis","",coverageFilePath))
siteCoverageData <- loadData(coverageFilePath)
msiOut <- msiDetect(siteCoverageData, msi_baseline, "testSample", msi_threshold)
print(msiOut)
```

```
## $msi_status
##       Sample msi.score msi.type
## 1 testSample    300.87    MSI-H
## 
## $lociInfo
##                                                          Site mssPattern
## 11 102193508 CTGGT 26[A] GCCAC 11 102193508 CTGGT 26[A] GCCAC      22,25
## 15 91303186 AAGAC 16[T] AGTGA   15 91303186 AAGAC 16[T] AGTGA      15,16
## 2 47641559 CAGGT 27[A] GGGTT     2 47641559 CAGGT 27[A] GGGTT      21,25
## 14 23652346 TTGCT 21[A] GGCCA   14 23652346 TTGCT 21[A] GGCCA      21,24
## 11 108114661 AATAA 15[T] AAGAA 11 108114661 AATAA 15[T] AAGAA      15,15
## 2 39573062 GTCTC 27[A] GAGTG     2 39573062 GTCTC 27[A] GAGTG      22,27
## 11 125490765 GAAGA 21[T] AATAT 11 125490765 GAAGA 21[T] AATAT      19,21
## 7 116381121 TGGTG 16[T] GGTTT   7 116381121 TGGTG 16[T] GGTTT      15,16
##                                msiPattern      N    K meanH    sdH
## 11 102193508 CTGGT 26[A] GCCAC         16 190588  504 0.629  1.294
## 15 91303186 AAGAC 16[T] AGTGA          11  64693  135 0.975  0.854
## 2 47641559 CAGGT 27[A] GGGTT           15 312366  661 0.522  1.149
## 14 23652346 TTGCT 21[A] GGCCA          15 699653 1488 2.900 13.986
## 11 108114661 AATAA 15[T] AAGAA         12 493030  782 0.157  0.329
## 2 39573062 GTCTC 27[A] GAGTG           17 135044  359 1.843  4.190
## 11 125490765 GAAGA 21[T] AATAT         15 709063 1268 1.767  4.747
## 7 116381121 TGGTG 16[T] GGTTT          11 787793  693 0.720  4.514
##                                varReads totalReads pvalue hzscore
## 11 102193508 CTGGT 26[A] GCCAC       31       1723  0.000  29.181
## 15 91303186 AAGAC 16[T] AGTGA        15        231  0.000  50.584
## 2 47641559 CAGGT 27[A] GGGTT         51       2176  0.000  72.369
## 14 23652346 TTGCT 21[A] GGCCA        56       5845  0.000   3.066
## 11 108114661 AATAA 15[T] AAGAA       33       2671  0.000 134.344
## 2 39573062 GTCTC 27[A] GAGTG         26       1357  0.000   7.756
## 11 125490765 GAAGA 21[T] AATAT       25       3932  0.000   3.308
## 7 116381121 TGGTG 16[T] GGTTT         3       2304  0.147   0.265
```
